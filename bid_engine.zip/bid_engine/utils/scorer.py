# utils/scorer.py
import pandas as pd
import numpy as np
from utils.rag_engine import search_capabilities
from utils.data_loader import load_bid_history

# ── Compliance Checker ───────────────────────────────────────────────────────

COMPLIANCE_THRESHOLD = 0.25  # similarity score above this = we have evidence

def check_compliance(mandatory_requirements: list) -> dict:
    """
    For each mandatory requirement, search the capability library.
    Returns a compliance report with pass/fail for each requirement.
    """
    results = []
    passed = 0

    for req in mandatory_requirements:
        matches = search_capabilities(req, top_k=1)
        if not matches:
            status = "❌ Gap"
            best_match = "No match found"
            score = 0.0
        else:
            top = matches[0]
            score = top["score"]
            if score >= COMPLIANCE_THRESHOLD:
                status = "✅ Pass"
                best_match = f"[{top['cap_id']}] {top['domain']} — {top['summary'][:80]}..."
                passed += 1
            else:
                status = "❌ Gap"
                best_match = f"Closest: [{top['cap_id']}] {top['domain']} (low confidence)"

        results.append({
            "requirement": req,
            "status": status,
            "best_match": best_match,
            "confidence": round(score, 3)
        })

    compliance_rate = round((passed / len(mandatory_requirements)) * 100, 1) if mandatory_requirements else 0

    return {
        "items": results,
        "passed": passed,
        "total": len(mandatory_requirements),
        "compliance_rate": compliance_rate
    }


# ── Win Probability Scorer ───────────────────────────────────────────────────

def calculate_win_probability(rfp_data: dict, compliance_report: dict) -> dict:
    """
    Calculate win probability using historical bid data + compliance rate.
    Returns a score breakdown dict for the dashboard.
    """
    df = load_bid_history()
    sector = rfp_data.get("sector", "")

    # ── Factor 1: Historical Win Rate in This Sector (0-100) ──
    sector_bids = df[df["Sector"].str.lower() == sector.lower()]
    if len(sector_bids) > 0:
        wins = (sector_bids["Outcome"] == "Win").sum()
        sector_win_rate = round((wins / len(sector_bids)) * 100, 1)
        sector_sample = len(sector_bids)
    else:
        # No history for this sector — use overall average
        wins = (df["Outcome"] == "Win").sum()
        sector_win_rate = round((wins / len(df)) * 100, 1)
        sector_sample = len(df)

    # ── Factor 2: Compliance Score (0-100) ──
    compliance_score = compliance_report["compliance_rate"]

    # ── Factor 3: Historical Avg Score in Sector ──
    if len(sector_bids) > 0:
        avg_sector_score = round(sector_bids["Score (%)"].mean(), 1)
    else:
        avg_sector_score = round(df["Score (%)"].mean(), 1)

    # ── Factor 4: Budget Competitiveness ──
    # Parse the RFP budget and compare to historical wins in sector
    budget_score = 50  # default neutral
    rfp_budget_str = rfp_data.get("budget") or ""
    try:
        # Extract numeric value (handles "PKR 85 Million", "PKR 85M", etc.)
        import re
        nums = re.findall(r"[\d.]+", rfp_budget_str.replace(",", ""))
        if nums:
            rfp_budget_val = float(nums[0])
            # Check if this is in Millions already or needs conversion
            if "million" in rfp_budget_str.lower():
                rfp_budget_val = rfp_budget_val  # already in M
            won_bids = sector_bids[sector_bids["Outcome"] == "Win"] if len(sector_bids) > 0 else df[df["Outcome"] == "Win"]
            if len(won_bids) > 0:
                avg_won_budget = won_bids["Budget_Numeric"].mean()
                ratio = rfp_budget_val / avg_won_budget if avg_won_budget > 0 else 1
                # Sweet spot: ratio close to 1 = similar to bids we usually win
                if 0.5 <= ratio <= 2.0:
                    budget_score = 75
                elif 0.3 <= ratio <= 3.0:
                    budget_score = 55
                else:
                    budget_score = 35
    except Exception:
        budget_score = 50

    # ── Weighted Final Score ──
    # Weights: compliance 35%, sector win rate 30%, avg score 20%, budget 15%
    final_score = round(
        (compliance_score * 0.35) +
        (sector_win_rate  * 0.30) +
        (avg_sector_score * 0.20) +
        (budget_score     * 0.15),
        1
    )

    # ── GO / NO-GO Decision ──
    if final_score >= 65:
        decision = "🟢 GO"
        rationale = "Strong compliance and favorable historical win rate. Recommend bidding."
    elif final_score >= 45:
        decision = "🟡 CONDITIONAL GO"
        rationale = "Moderate score. Address compliance gaps before committing full bid effort."
    else:
        decision = "🔴 NO-GO"
        rationale = "Low compliance or poor historical performance in this sector. High risk."

    return {
        "final_score": final_score,
        "decision": decision,
        "rationale": rationale,
        "breakdown": {
            "Compliance Rate":        {"score": compliance_score,   "weight": "35%"},
            "Sector Win Rate":        {"score": sector_win_rate,    "weight": "30%", "sample": sector_sample},
            "Avg Historical Score":   {"score": avg_sector_score,   "weight": "20%"},
            "Budget Competitiveness": {"score": budget_score,       "weight": "15%"},
        }
    }
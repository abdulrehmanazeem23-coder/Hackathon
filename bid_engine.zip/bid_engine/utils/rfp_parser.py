# utils/rfp_parser.py
import os
import json
import re
from groq import Groq
from pypdf import PdfReader
from docx import Document
from dotenv import load_dotenv

load_dotenv()
client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

# ── Text Extraction ──────────────────────────────────────────────────────────

def extract_text_from_pdf(file_path: str) -> str:
    reader = PdfReader(file_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    return text.strip()

def extract_text_from_docx(file_path: str) -> str:
    doc = Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs]).strip()

def extract_text(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        return extract_text_from_pdf(file_path)
    elif ext in (".docx", ".doc"):
        return extract_text_from_docx(file_path)
    else:
        raise ValueError(f"Unsupported file type: {ext}")

# ── LLM Extraction ───────────────────────────────────────────────────────────

EXTRACTION_PROMPT = """You are an expert bid analyst. Analyze the following RFP/tender document excerpt and extract structured information.

Return ONLY a valid JSON object with exactly these keys:
{{
  "title": "Project title or name of the tender",
  "client": "Issuing organization name",
  "sector": "One of: IT Services, Construction, Healthcare, Energy, Logistics, Education, Finance, Telecom, Other",
  "deadline": "Submission deadline date if mentioned, else null",
  "budget": "Budget figure if mentioned, else null",
  "mandatory_requirements": [
    "Requirement 1 (start each with MUST, SHALL, or REQUIRED)",
    "Requirement 2",
    "..."
  ],
  "evaluation_criteria": [
    {{"criterion": "Technical Approach", "weight": "40%"}},
    {{"criterion": "Price", "weight": "30%"}}
  ],
  "key_questions": [
    "Question or section the vendor must respond to",
    "..."
  ],
  "summary": "2-3 sentence plain English summary of what this bid is about"
}}

Extract up to 10 mandatory requirements, up to 6 evaluation criteria, and up to 8 key questions.
If a field cannot be found, use null for strings or [] for arrays.
Return ONLY the JSON. No explanation, no markdown, no code fences.

RFP TEXT:
{rfp_text}"""

def parse_rfp(file_path: str) -> dict:
    """
    Main function: takes a PDF or DOCX path, returns structured RFP data as a dict.
    """
    print(f"📄 Extracting text from {os.path.basename(file_path)}...")
    raw_text = extract_text(file_path)

    if not raw_text or len(raw_text) < 100:
        raise ValueError("Could not extract meaningful text from this document. It may be a scanned image-only PDF.")

    # Truncate to ~12,000 chars to stay within token limits (Groq is fast but has limits)
    truncated_text = raw_text[:12000]
    if len(raw_text) > 12000:
        print(f"⚠️  Document is long ({len(raw_text)} chars). Using first 12,000 chars for extraction.")

    print("🤖 Sending to Groq LLM for intelligent extraction...")
    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {
                "role": "user",
                "content": EXTRACTION_PROMPT.format(rfp_text=truncated_text)
            }
        ],
        temperature=0.1,   # Low temperature = more deterministic, less creative
        max_tokens=2000,
    )

    raw_json = response.choices[0].message.content.strip()

    # Clean up in case the model wraps it in markdown fences anyway
    raw_json = re.sub(r"^```json\s*", "", raw_json)
    raw_json = re.sub(r"^```\s*", "", raw_json)
    raw_json = re.sub(r"\s*```$", "", raw_json)

    try:
        parsed = json.loads(raw_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"LLM returned invalid JSON: {e}\n\nRaw output:\n{raw_json[:500]}")

    parsed["raw_text"] = raw_text        # keep full text for later RAG use
    parsed["source_file"] = os.path.basename(file_path)
    parsed["char_count"] = len(raw_text)

    print(f"✅ RFP parsed successfully! Found {len(parsed.get('mandatory_requirements', []))} requirements.")
    return parsed
# utils/data_loader.py
import pandas as pd

DATA_PATH = "data/sample_data.xlsx"

def load_bid_history():
    df = pd.read_excel(DATA_PATH, sheet_name="PS1 \u2013 Bid History", header=2)
    df = df.dropna(how='all')
    # Parse budget as numeric (strip 'PKR ' and 'M')
    df['Budget_Numeric'] = (
        df['Budget']
        .str.replace('PKR ', '', regex=False)
        .str.replace('M', '', regex=False)
        .str.strip()
        .astype(float)
    )
    return df

def load_capability_library():
    df = pd.read_excel(DATA_PATH, sheet_name="PS1 \u2013 Capability Library", header=2)
    df = df.dropna(how='all')
    # Create a rich text field for embedding (combines domain + summary + cert)
    df['embed_text'] = (
        df['Domain'].fillna('') + ". " +
        df['Project Summary'].fillna('') + ". " +
        "Certification: " + df['Certification'].fillna('None') + ". " +
        "Client Type: " + df['Client Type'].fillna('Unknown') + "."
    )
    return df
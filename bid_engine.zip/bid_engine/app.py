# app.py  — BidIQ | AI-Powered Bid Response Engine | Lava Fire Theme
import os, json, tempfile
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from dotenv import load_dotenv

load_dotenv()

# ── Page Config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="BidIQ — Bid Response Engine",
    page_icon="🔥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── LAVA FIRE CSS THEME ──────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Rajdhani:wght@500;600;700&display=swap');

/* ── Root variables ── */
:root {
    --lava-core:    #FF4500;
    --lava-hot:     #FF6B1A;
    --lava-mid:     #FF8C00;
    --lava-glow:    #FFA500;
    --lava-ember:   #FFD700;
    --obsidian:     #080808;
    --crust-dark:   #100E0C;
    --crust-mid:    #1A1612;
    --crust-light:  #241E18;
    --crust-border: #3D2E1E;
    --ash-text:     #E8D5C0;
    --ash-muted:    #9B8878;
    --ash-dim:      #5C4A3A;
    --smoke-white:  #F5EDE4;
}

/* ── Global base ── */
html, body, .stApp {
    background: var(--obsidian) !important;
    font-family: 'Inter', sans-serif !important;
    color: var(--ash-text) !important;
}

/* ── Animated lava background ── */
.stApp::before {
    content: '';
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background:
        radial-gradient(ellipse 80% 50% at 20% 80%, rgba(255,69,0,0.08) 0%, transparent 60%),
        radial-gradient(ellipse 60% 40% at 80% 20%, rgba(255,140,0,0.06) 0%, transparent 50%),
        radial-gradient(ellipse 40% 30% at 50% 50%, rgba(255,107,26,0.04) 0%, transparent 70%);
    pointer-events: none;
    z-index: 0;
}

/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg,
        #120D09 0%,
        #1A1208 40%,
        #0F0B07 100%) !important;
    border-right: 1px solid var(--crust-border) !important;
}
[data-testid="stSidebar"]::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: linear-gradient(90deg, var(--lava-core), var(--lava-mid), var(--lava-ember));
}

/* ── Sidebar text ── */
[data-testid="stSidebar"] p,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] .stMarkdown {
    color: var(--ash-text) !important;
}

/* ── Main content block ── */
.main .block-container {
    background: transparent !important;
    padding-top: 1.5rem !important;
}

/* ── Headings ── */
h1, h2, h3 {
    font-family: 'Rajdhani', sans-serif !important;
    letter-spacing: 0.04em !important;
}
h1 { font-size: 2.4rem !important; font-weight: 700 !important; }
h2 { font-size: 1.7rem !important; font-weight: 600 !important; }
h3 { font-size: 1.3rem !important; font-weight: 600 !important; }

/* Gradient heading text */
.fire-title {
    font-family: 'Rajdhani', sans-serif;
    font-size: 2.8rem;
    font-weight: 800;
    background: linear-gradient(135deg,
        #FF4500 0%, #FF6B1A 25%, #FF8C00 50%, #FFD700 75%, #FF8C00 100%);
    background-size: 200% auto;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    animation: fireShimmer 4s linear infinite;
    letter-spacing: 0.05em;
    line-height: 1.1;
}
@keyframes fireShimmer {
    0%   { background-position: 0% center; }
    100% { background-position: 200% center; }
}

/* ── Lava divider ── */
.lava-divider {
    height: 2px;
    background: linear-gradient(90deg,
        transparent, var(--lava-core) 20%, var(--lava-mid) 50%, var(--lava-glow) 80%, transparent);
    margin: 1rem 0;
    border-radius: 2px;
}

/* ── Metric / stat cards ── */
[data-testid="stMetric"] {
    background: linear-gradient(135deg,
        rgba(26,18,8,0.95) 0%,
        rgba(36,26,16,0.9) 100%) !important;
    border: 1px solid var(--crust-border) !important;
    border-top: 2px solid var(--lava-core) !important;
    border-radius: 10px !important;
    padding: 14px 18px !important;
    box-shadow: 0 4px 24px rgba(255,69,0,0.12),
                inset 0 1px 0 rgba(255,140,0,0.1) !important;
}
[data-testid="stMetricLabel"] {
    color: var(--ash-muted) !important;
    font-size: 0.75rem !important;
    font-weight: 600 !important;
    letter-spacing: 0.1em !important;
    text-transform: uppercase !important;
}
[data-testid="stMetricValue"] {
    color: var(--lava-glow) !important;
    font-family: 'Rajdhani', sans-serif !important;
    font-weight: 700 !important;
    font-size: 1.6rem !important;
}

/* ── Tabs ── */
.stTabs [data-baseweb="tab-list"] {
    background: linear-gradient(90deg, var(--crust-dark), var(--crust-mid)) !important;
    border: 1px solid var(--crust-border) !important;
    border-radius: 10px !important;
    padding: 5px !important;
    gap: 4px !important;
}
.stTabs [data-baseweb="tab"] {
    color: var(--ash-muted) !important;
    border-radius: 8px !important;
    font-weight: 500 !important;
    font-size: 0.85rem !important;
    letter-spacing: 0.02em !important;
    transition: all 0.2s ease !important;
}
.stTabs [aria-selected="true"] {
    background: linear-gradient(135deg, rgba(255,69,0,0.3), rgba(255,140,0,0.2)) !important;
    color: var(--lava-glow) !important;
    border: 1px solid rgba(255,100,0,0.4) !important;
    box-shadow: 0 0 12px rgba(255,69,0,0.2) !important;
}

/* ── Primary button ── */
.stButton > button[kind="primary"] {
    background: linear-gradient(135deg,
        var(--lava-core) 0%,
        var(--lava-hot) 40%,
        var(--lava-mid) 80%,
        var(--lava-glow) 100%) !important;
    background-size: 200% auto !important;
    border: none !important;
    color: #0A0600 !important;
    font-weight: 700 !important;
    font-family: 'Rajdhani', sans-serif !important;
    font-size: 1.05rem !important;
    letter-spacing: 0.06em !important;
    border-radius: 8px !important;
    padding: 0.55rem 1.5rem !important;
    transition: all 0.3s ease !important;
    box-shadow: 0 4px 20px rgba(255,69,0,0.4) !important;
}
.stButton > button[kind="primary"]:hover {
    background-position: right center !important;
    box-shadow: 0 6px 28px rgba(255,69,0,0.6) !important;
    transform: translateY(-1px) !important;
}

/* ── Secondary button ── */
.stButton > button:not([kind="primary"]) {
    background: transparent !important;
    border: 1px solid var(--crust-border) !important;
    color: var(--ash-text) !important;
    border-radius: 8px !important;
    transition: all 0.2s !important;
}
.stButton > button:not([kind="primary"]):hover {
    border-color: var(--lava-core) !important;
    color: var(--lava-glow) !important;
    background: rgba(255,69,0,0.06) !important;
}

/* ── File uploader ── */
[data-testid="stFileUploader"] {
    background: linear-gradient(135deg,
        rgba(26,18,8,0.8),
        rgba(16,12,7,0.9)) !important;
    border: 1.5px dashed var(--crust-border) !important;
    border-radius: 10px !important;
    transition: border-color 0.3s !important;
}
[data-testid="stFileUploader"]:hover {
    border-color: var(--lava-core) !important;
}

/* ── Expander ── */
[data-testid="stExpander"] {
    background: linear-gradient(135deg,
        rgba(20,14,8,0.9),
        rgba(28,20,10,0.85)) !important;
    border: 1px solid var(--crust-border) !important;
    border-left: 3px solid var(--lava-core) !important;
    border-radius: 8px !important;
    margin: 6px 0 !important;
}
[data-testid="stExpander"] summary {
    color: var(--ash-text) !important;
    font-weight: 500 !important;
}

/* ── Info / warning / success boxes ── */
[data-testid="stAlert"] {
    border-radius: 8px !important;
    border-left-width: 3px !important;
}

/* ── Text areas ── */
textarea {
    background: var(--crust-mid) !important;
    border: 1px solid var(--crust-border) !important;
    color: var(--ash-text) !important;
    border-radius: 8px !important;
    font-family: 'Inter', sans-serif !important;
}
textarea:focus {
    border-color: var(--lava-core) !important;
    box-shadow: 0 0 0 2px rgba(255,69,0,0.2) !important;
}

/* ── Progress bar ── */
[data-testid="stProgressBar"] > div > div {
    background: linear-gradient(90deg,
        var(--lava-core), var(--lava-mid), var(--lava-ember)) !important;
}

/* ── Download button ── */
[data-testid="stDownloadButton"] > button {
    background: linear-gradient(135deg,
        rgba(255,69,0,0.15), rgba(255,140,0,0.1)) !important;
    border: 1px solid rgba(255,100,0,0.4) !important;
    color: var(--lava-glow) !important;
    font-weight: 600 !important;
    border-radius: 8px !important;
    width: 100% !important;
    transition: all 0.2s !important;
}
[data-testid="stDownloadButton"] > button:hover {
    background: linear-gradient(135deg,
        rgba(255,69,0,0.3), rgba(255,140,0,0.2)) !important;
    box-shadow: 0 4px 16px rgba(255,69,0,0.3) !important;
}

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: var(--crust-dark); }
::-webkit-scrollbar-thumb {
    background: linear-gradient(var(--lava-core), var(--lava-mid));
    border-radius: 3px;
}

/* ── Custom card components ── */
.lava-card {
    background: linear-gradient(135deg,
        rgba(26,18,8,0.95) 0%,
        rgba(20,14,8,0.9) 100%);
    border: 1px solid var(--crust-border);
    border-radius: 12px;
    padding: 20px 24px;
    margin: 10px 0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4),
                inset 0 1px 0 rgba(255,120,0,0.08);
}
.lava-card-accent {
    border-top: 2px solid var(--lava-core);
}

/* Decision banners */
.go-banner {
    background: linear-gradient(135deg, #051A0A 0%, #0A2E12 50%, #051A0A 100%);
    border: 1px solid #1A6B30;
    border-left: 4px solid #2ECC71;
    border-radius: 12px;
    padding: 22px 30px;
    text-align: center;
    font-family: 'Rajdhani', sans-serif;
    font-size: 2rem;
    font-weight: 700;
    color: #2ECC71;
    margin-bottom: 20px;
    box-shadow: 0 0 40px rgba(46,204,113,0.15),
                inset 0 1px 0 rgba(46,204,113,0.1);
}
.conditional-banner {
    background: linear-gradient(135deg, #1A1200 0%, #2E2000 50%, #1A1200 100%);
    border: 1px solid #6B5000;
    border-left: 4px solid #F1C40F;
    border-radius: 12px;
    padding: 22px 30px;
    text-align: center;
    font-family: 'Rajdhani', sans-serif;
    font-size: 2rem;
    font-weight: 700;
    color: #F1C40F;
    margin-bottom: 20px;
    box-shadow: 0 0 40px rgba(241,196,15,0.1);
}
.nogo-banner {
    background: linear-gradient(135deg, #1A0505 0%, #2E0808 50%, #1A0505 100%);
    border: 1px solid var(--lava-core);
    border-left: 4px solid #E74C3C;
    border-radius: 12px;
    padding: 22px 30px;
    text-align: center;
    font-family: 'Rajdhani', sans-serif;
    font-size: 2rem;
    font-weight: 700;
    color: #E74C3C;
    margin-bottom: 20px;
    box-shadow: 0 0 40px rgba(231,76,60,0.15);
}

/* Requirement rows */
.req-pass {
    background: linear-gradient(135deg, rgba(5,20,10,0.9), rgba(10,30,15,0.85));
    border-left: 3px solid #2ECC71;
    border-radius: 8px;
    padding: 12px 16px;
    margin: 6px 0;
    color: #C8E6D0;
}
.req-gap {
    background: linear-gradient(135deg, rgba(20,5,5,0.9), rgba(35,8,8,0.85));
    border-left: 3px solid var(--lava-core);
    border-radius: 8px;
    padding: 12px 16px;
    margin: 6px 0;
    color: #E8C4C0;
}

/* Capability evidence chip */
.cap-chip {
    background: linear-gradient(135deg, rgba(36,26,16,0.95), rgba(26,18,8,0.9));
    border: 1px solid var(--crust-border);
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 0.82rem;
    text-align: center;
}

/* Section draft card */
.draft-card {
    background: linear-gradient(135deg,
        rgba(18,12,6,0.97) 0%,
        rgba(26,18,10,0.92) 100%);
    border: 1px solid var(--crust-border);
    border-top: 2px solid var(--lava-hot);
    border-radius: 10px;
    padding: 20px 22px;
    margin: 8px 0;
}

footer { visibility: hidden; }
#MainMenu { visibility: hidden; }
</style>
""", unsafe_allow_html=True)


# ── Session State ─────────────────────────────────────────────────────────────
for key in ["rfp_data", "compliance", "win_data", "cap_matches", "draft_sections"]:
    if key not in st.session_state:
        st.session_state[key] = None


# ── SIDEBAR ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding: 10px 0 6px;">
        <div style="font-family:'Rajdhani',sans-serif; font-size:1.8rem; font-weight:800;
            background:linear-gradient(135deg,#FF4500,#FF8C00,#FFD700);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
            background-clip:text; letter-spacing:0.06em;">
            🔥 BidIQ
        </div>
        <div style="color:#9B8878; font-size:0.75rem; letter-spacing:0.12em;
            text-transform:uppercase; margin-top:2px;">
            AI Bid Response Engine
        </div>
    </div>
    <div class="lava-divider"></div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <p style="color:#9B8878; font-size:0.75rem; font-weight:600;
       letter-spacing:0.1em; text-transform:uppercase; margin-bottom:8px;">
       Upload RFP Document
    </p>
    """, unsafe_allow_html=True)

    uploaded_file = st.file_uploader(
        "",
        type=["pdf", "docx"],
        help="Upload any RFP, RFQ, or Tender document (PDF or DOCX)",
        label_visibility="collapsed"
    )

    if uploaded_file:
        st.markdown(f"""
        <div style="background:linear-gradient(135deg,rgba(255,69,0,0.1),rgba(255,140,0,0.06));
            border:1px solid rgba(255,100,0,0.3); border-radius:8px;
            padding:10px 14px; margin:8px 0; font-size:0.85rem; color:#FFA500;">
            ✅ &nbsp;<b>{uploaded_file.name}</b><br>
            <span style="color:#9B8878; font-size:0.75rem;">
                {round(uploaded_file.size/1024,1)} KB
            </span>
        </div>
        """, unsafe_allow_html=True)
        analyze_btn = st.button("🔥 Ignite Analysis", type="primary", use_container_width=True)
    else:
        st.markdown("""
        <div style="background:rgba(20,14,8,0.6); border:1px dashed #3D2E1E;
            border-radius:8px; padding:14px; text-align:center; color:#5C4A3A;
            font-size:0.83rem; margin:8px 0;">
            Drop a PDF or DOCX to begin
        </div>
        """, unsafe_allow_html=True)
        analyze_btn = False

    st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)

    st.markdown("""
    <p style="color:#9B8878; font-size:0.75rem; font-weight:600;
       letter-spacing:0.1em; text-transform:uppercase; margin-bottom:10px;">
       Historical Database
    </p>
    """, unsafe_allow_html=True)
    try:
        from utils.data_loader import load_bid_history, load_capability_library
        df_bids = load_bid_history()
        df_caps = load_capability_library()
        wins = (df_bids["Outcome"] == "Win").sum()
        total = len(df_bids)
        c1, c2 = st.columns(2)
        c1.metric("Bids", total)
        c2.metric("Win Rate", f"{round(wins/total*100,1)}%")
        st.metric("Capabilities", len(df_caps))
    except Exception:
        st.warning("Could not load historical data.")

    st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)
    st.markdown("""
    <div style="color:#5C4A3A; font-size:0.72rem; text-align:center;
        letter-spacing:0.05em; padding-top:4px;">
        TekRowe Hackathon · Problem Statement 1
    </div>
    """, unsafe_allow_html=True)


# ── HERO HEADER ───────────────────────────────────────────────────────────────
st.markdown("""
<div style="padding: 10px 0 4px;">
    <div class="fire-title">BidIQ</div>
    <div style="color:#9B8878; font-size:0.9rem; letter-spacing:0.08em;
        text-transform:uppercase; margin-top:4px; margin-bottom:4px;">
        AI-Powered Bid &amp; Proposal Response Engine
    </div>
</div>
<div class="lava-divider"></div>
""", unsafe_allow_html=True)

if not st.session_state.rfp_data:
    st.markdown("""
    <div style="color:#5C4A3A; font-size:0.9rem; margin-bottom:1rem;">
        Upload an RFP on the left and click
        <span style="color:#FF6B1A; font-weight:600;">🔥 Ignite Analysis</span>
        to extract requirements, check compliance, and generate a full proposal draft.
    </div>
    """, unsafe_allow_html=True)


# ── ANALYSIS TRIGGER ──────────────────────────────────────────────────────────
if analyze_btn and uploaded_file:
    with st.spinner("⚙️ Warming up AI modules..."):
        from utils.rfp_parser import parse_rfp
        from utils.scorer import check_compliance, calculate_win_probability
        from utils.rag_engine import search_capabilities

    suffix = ".pdf" if uploaded_file.name.endswith(".pdf") else ".docx"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded_file.read())
        tmp_path = tmp.name

    try:
        with st.spinner("📄 Extracting & parsing RFP with AI..."):
            rfp_data = parse_rfp(tmp_path)
        with st.spinner("🔍 Running compliance check..."):
            compliance = check_compliance(rfp_data.get("mandatory_requirements", []))
        with st.spinner("📈 Scoring win probability..."):
            win_data = calculate_win_probability(rfp_data, compliance)
        with st.spinner("🔎 Matching capabilities..."):
            cap_matches = {}
            for req in rfp_data.get("mandatory_requirements", []):
                cap_matches[req] = search_capabilities(req, top_k=3)

        st.session_state.rfp_data     = rfp_data
        st.session_state.compliance   = compliance
        st.session_state.win_data     = win_data
        st.session_state.cap_matches  = cap_matches
        st.session_state.draft_sections = None   # reset draft on new upload
        st.success("✅ Analysis complete — explore the tabs below.")
    except Exception as e:
        st.error(f"❌ Error: {str(e)}")
        st.stop()
    finally:
        os.unlink(tmp_path)


# ── RESULTS DASHBOARD ─────────────────────────────────────────────────────────
if st.session_state.rfp_data:
    rfp  = st.session_state.rfp_data
    comp = st.session_state.compliance
    win  = st.session_state.win_data
    caps = st.session_state.cap_matches

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📋  RFP Overview",
        "✅  Compliance",
        "📈  Win Probability",
        "🔎  Capabilities",
        "✍️  Draft Proposal",
    ])

    # ── PLOTLY SHARED THEME ───────────────────────────────────────────────────
    PL_BG    = "rgba(0,0,0,0)"
    PL_FONT  = dict(color="#E8D5C0", family="Inter")
    PL_GRID  = "#2A1E12"
    PL_LAVA  = ["#FF4500","#FF6B1A","#FF8C00","#FFA500","#FFD700"]

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 1 — RFP OVERVIEW
    # ══════════════════════════════════════════════════════════════════════════
    with tab1:
        st.markdown("## 📋 RFP Overview")
        st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Sector",   rfp.get("sector", "—"))
        c2.metric("Budget",   rfp.get("budget") or "—")
        c3.metric("Deadline", rfp.get("deadline") or "—")
        c4.metric("Doc Size", f"{rfp.get('char_count',0):,} chars")

        st.markdown("<br>", unsafe_allow_html=True)
        col_l, col_r = st.columns([3, 2])

        with col_l:
            st.markdown("### 🗒️ Project Summary")
            st.markdown(f"""
            <div class="lava-card lava-card-accent">
                <p style="color:#E8D5C0; line-height:1.75; margin:0; font-size:0.95rem;">
                    {rfp.get('summary','No summary available.')}
                </p>
            </div>""", unsafe_allow_html=True)

            st.markdown("### ❓ Key Sections to Answer")
            for i, q in enumerate(rfp.get("key_questions", []), 1):
                st.markdown(f"""
                <div style="background:rgba(255,69,0,0.05); border-left:2px solid #FF6B1A;
                    border-radius:0 6px 6px 0; padding:9px 14px; margin:5px 0;
                    color:#E8D5C0; font-size:0.88rem;">
                    <span style="color:#FF8C00; font-weight:700; font-family:'Rajdhani',sans-serif;
                        margin-right:8px;">Q{i}</span>{q}
                </div>""", unsafe_allow_html=True)

        with col_r:
            st.markdown("### 📌 Details")
            st.markdown(f"""
            <div class="lava-card">
                <div style="margin-bottom:14px;">
                    <div style="color:#9B8878;font-size:0.7rem;letter-spacing:.1em;
                        text-transform:uppercase;margin-bottom:3px;">Project Title</div>
                    <div style="color:#FFA500;font-weight:600;font-size:0.9rem;
                        font-family:'Rajdhani',sans-serif;">{rfp.get('title','—')}</div>
                </div>
                <div style="margin-bottom:14px;">
                    <div style="color:#9B8878;font-size:0.7rem;letter-spacing:.1em;
                        text-transform:uppercase;margin-bottom:3px;">Client</div>
                    <div style="color:#E8D5C0;font-size:0.9rem;">{rfp.get('client','—')}</div>
                </div>
                <div>
                    <div style="color:#9B8878;font-size:0.7rem;letter-spacing:.1em;
                        text-transform:uppercase;margin-bottom:3px;">Source File</div>
                    <div style="color:#E8D5C0;font-size:0.85rem;">{rfp.get('source_file','—')}</div>
                </div>
            </div>""", unsafe_allow_html=True)

            st.markdown("### ⚖️ Evaluation Criteria")
            for ec in rfp.get("evaluation_criteria", []):
                crit = ec.get("criterion","")
                wt   = ec.get("weight","")
                # Parse weight number for bar width
                try:
                    pct = int(str(wt).replace('%','').strip())
                except:
                    pct = 30
                st.markdown(f"""
                <div style="margin:6px 0;">
                    <div style="display:flex;justify-content:space-between;
                        font-size:0.82rem;color:#E8D5C0;margin-bottom:3px;">
                        <span>{crit}</span>
                        <span style="color:#FFA500;font-weight:600;">{wt}</span>
                    </div>
                    <div style="background:#1A1612;border-radius:3px;height:5px;">
                        <div style="background:linear-gradient(90deg,#FF4500,#FFD700);
                            width:{pct}%;height:5px;border-radius:3px;"></div>
                    </div>
                </div>""", unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 2 — COMPLIANCE
    # ══════════════════════════════════════════════════════════════════════════
    with tab2:
        st.markdown("## ✅ Compliance Checklist")
        st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)

        c1, c2, c3 = st.columns(3)
        c1.metric("Total Requirements", comp["total"])
        c2.metric("✅ Passed",           comp["passed"])
        c3.metric("❌ Gaps",             comp["total"] - comp["passed"])

        col_chart, col_list = st.columns([1, 2])

        with col_chart:
            passed = comp["passed"]
            failed = comp["total"] - comp["passed"]
            fig_d = go.Figure(go.Pie(
                labels=["Compliant","Gap"],
                values=[passed, failed],
                hole=0.68,
                marker=dict(
                    colors=["#FF6B1A","#2A1E12"],
                    line=dict(color="#080808", width=2)
                ),
                textinfo="none",
            ))
            fig_d.add_annotation(
                text=f"<b>{comp['compliance_rate']}%</b>",
                x=0.5, y=0.55,
                font=dict(size=28, color="#FFD700", family="Rajdhani"),
                showarrow=False
            )
            fig_d.add_annotation(
                text="compliant",
                x=0.5, y=0.38,
                font=dict(size=12, color="#9B8878", family="Inter"),
                showarrow=False
            )
            fig_d.update_layout(
                paper_bgcolor=PL_BG, plot_bgcolor=PL_BG,
                showlegend=False,
                margin=dict(t=10,b=10,l=10,r=10),
                height=220
            )
            st.plotly_chart(fig_d, use_container_width=True)

        with col_list:
            st.markdown("### Requirement Breakdown")
            for item in comp["items"]:
                css = "req-pass" if "Pass" in item["status"] else "req-gap"
                icon = "✅" if "Pass" in item["status"] else "❌"
                conf_color = "#2ECC71" if "Pass" in item["status"] else "#FF4500"
                st.markdown(f"""
                <div class="{css}">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <span style="font-weight:600;font-size:0.88rem;">{icon} {item['requirement'][:80]}</span>
                        <span style="color:{conf_color};font-size:0.75rem;font-weight:700;
                            font-family:'Rajdhani',sans-serif;">
                            {item['confidence']}
                        </span>
                    </div>
                    <div style="color:#9B8878;font-size:0.78rem;margin-top:4px;">
                        → {item['best_match'][:100]}
                    </div>
                </div>""", unsafe_allow_html=True)

        if comp["total"] - comp["passed"] > 0:
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown(f"""
            <div style="background:linear-gradient(135deg,rgba(255,69,0,0.1),rgba(255,100,0,0.06));
                border:1px solid rgba(255,69,0,0.3); border-radius:8px;
                padding:14px 18px; color:#FFA500; font-size:0.9rem;">
                ⚠️ &nbsp;<b>{comp['total']-comp['passed']} compliance gap(s) detected.</b>
                Prepare supporting documentation or subcontractor agreements to address these
                before submission.
            </div>""", unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 3 — WIN PROBABILITY
    # ══════════════════════════════════════════════════════════════════════════
    with tab3:
        st.markdown("## 📈 Win Probability Dashboard")
        st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)

        decision = win["decision"]
        if "NO" in decision and "CONDITIONAL" not in decision:
            bcls = "nogo-banner"
        elif "CONDITIONAL" in decision:
            bcls = "conditional-banner"
        else:
            bcls = "go-banner"

        st.markdown(
            f'<div class="{bcls}">'
            f'{decision}&nbsp;&nbsp;|&nbsp;&nbsp;Score: {win["final_score"]} / 100'
            f'</div>',
            unsafe_allow_html=True
        )
        st.markdown(f"""
        <div style="color:#9B8878; font-size:0.88rem; margin-bottom:1rem;">
            💬 {win['rationale']}
        </div>""", unsafe_allow_html=True)

        col_bar, col_cards = st.columns([3, 2])

        with col_bar:
            breakdown = win["breakdown"]
            factors = list(breakdown.keys())
            scores  = [breakdown[f]["score"] for f in factors]
            colors  = ["#FF4500" if s < 45 else "#FF8C00" if s < 65 else "#2ECC71"
                       for s in scores]

            fig_b = go.Figure(go.Bar(
                x=scores, y=factors, orientation="h",
                marker=dict(
                    color=colors,
                    line=dict(color="#080808", width=1)
                ),
                text=[f"{s:.1f}" for s in scores],
                textposition="inside",
                textfont=dict(color="#0A0600", size=13, family="Rajdhani"),
            ))
            fig_b.add_vline(
                x=65, line_dash="dot", line_color="#FFD700", line_width=1.5,
                annotation_text="GO",
                annotation_font=dict(color="#FFD700", size=11)
            )
            fig_b.update_layout(
                paper_bgcolor=PL_BG, plot_bgcolor=PL_BG,
                xaxis=dict(range=[0,100], color="#9B8878",
                           gridcolor=PL_GRID, gridwidth=0.5, zeroline=False),
                yaxis=dict(color="#E8D5C0", gridcolor=PL_GRID),
                height=260, margin=dict(t=10,b=10,l=10,r=10),
                font=PL_FONT,
            )
            st.plotly_chart(fig_b, use_container_width=True)

        with col_cards:
            st.markdown("### Factor Scores")
            for factor, data in breakdown.items():
                s = data["score"]
                col_s = "#2ECC71" if s >= 65 else "#FF8C00" if s >= 45 else "#FF4500"
                bar_w = int(s)
                sample_str = f" · n={data['sample']}" if "sample" in data else ""
                st.markdown(f"""
                <div class="lava-card" style="padding:12px 16px; margin:5px 0;">
                    <div style="display:flex;justify-content:space-between;align-items:baseline;">
                        <span style="font-size:0.82rem;color:#9B8878;">{factor}{sample_str}</span>
                        <span style="color:{col_s};font-size:1.3rem;font-weight:700;
                            font-family:'Rajdhani',sans-serif;">{s:.1f}</span>
                    </div>
                    <div style="background:#1A1612;border-radius:2px;height:4px;margin-top:6px;">
                        <div style="background:{col_s};width:{bar_w}%;height:4px;border-radius:2px;"></div>
                    </div>
                    <div style="color:#5C4A3A;font-size:0.7rem;margin-top:4px;">
                        weight {data['weight']}
                    </div>
                </div>""", unsafe_allow_html=True)

        # Sector chart
        st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)
        st.markdown("### 🌋 Historical Win Rate by Sector")
        try:
            from utils.data_loader import load_bid_history
            df = load_bid_history()
            sg = df.groupby("Sector").apply(
                lambda x: round((x["Outcome"]=="Win").sum()/len(x)*100, 1)
            ).reset_index()
            sg.columns = ["Sector","Win Rate (%)"]
            sg = sg.sort_values("Win Rate (%)", ascending=True)

            fig_s = go.Figure(go.Bar(
                x=sg["Win Rate (%)"], y=sg["Sector"],
                orientation="h",
                marker=dict(
                    color=sg["Win Rate (%)"],
                    colorscale=[[0,"#FF4500"],[0.5,"#FF8C00"],[1,"#FFD700"]],
                    line=dict(color="#080808", width=0.5)
                ),
                text=[f"{v}%" for v in sg["Win Rate (%)"]],
                textposition="outside",
                textfont=dict(color="#9B8878", size=11),
            ))
            current_sector = rfp.get("sector","")
            fig_s.add_vline(x=65, line_dash="dot", line_color="#FFD700",
                            line_width=1.5,
                            annotation_text="target", annotation_position="top",
                            annotation_font=dict(color="#FFD700", size=10))
            fig_s.update_layout(
                paper_bgcolor=PL_BG, plot_bgcolor=PL_BG,
                xaxis=dict(range=[0,110], color="#9B8878",
                           gridcolor=PL_GRID, gridwidth=0.5, zeroline=False),
                yaxis=dict(color="#E8D5C0"),
                height=340, margin=dict(t=10,b=10,l=10,r=60),
                font=PL_FONT,
            )
            st.plotly_chart(fig_s, use_container_width=True)
        except Exception:
            st.info("Could not load sector chart.")

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 4 — CAPABILITIES
    # ══════════════════════════════════════════════════════════════════════════
    with tab4:
        st.markdown("## 🔎 Capability Matches")
        st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)
        st.markdown("""
        <div style="color:#9B8878;font-size:0.85rem;margin-bottom:1rem;">
            For each mandatory requirement, the top 3 most relevant past projects
            from your Capability Library are shown.
        </div>""", unsafe_allow_html=True)

        for req, matches in caps.items():
            with st.expander(f"🔒 {req[:90]}{'...' if len(req)>90 else ''}"):
                if not matches:
                    st.warning("No matches found.")
                    continue
                cols = st.columns(len(matches))
                for col, m in zip(cols, matches):
                    sc = m["score"]
                    col_c = "#2ECC71" if sc >= 0.25 else "#FF8C00" if sc >= 0.15 else "#FF4500"
                    cert_val = m['certification'] if str(m['certification']) != 'nan' else 'None'
                    col.markdown(f"""
                    <div class="lava-card" style="padding:12px 14px;">
                        <div style="color:{col_c};font-family:'Rajdhani',sans-serif;
                            font-weight:700;font-size:1rem;margin-bottom:4px;">
                            [{m['cap_id']}]
                        </div>
                        <div style="color:#FFA500;font-weight:600;font-size:0.85rem;
                            margin-bottom:6px;">{m['domain']}</div>
                        <div style="color:#E8D5C0;font-size:0.78rem;line-height:1.5;
                            margin-bottom:8px;">{m['summary'][:100]}...</div>
                        <div style="color:{col_c};font-size:0.75rem;font-weight:700;
                            font-family:'Rajdhani',sans-serif;margin-bottom:6px;">
                            Match: {sc:.3f}
                        </div>
                        <div style="border-top:1px solid #3D2E1E;padding-top:6px;
                            color:#9B8878;font-size:0.7rem;line-height:1.6;">
                            📜 {cert_val}<br>
                            👤 {m['client_type']}<br>
                            💰 {m['contract_value']}
                        </div>
                    </div>""", unsafe_allow_html=True)

        st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)
        st.markdown("### 📥 Export Full Analysis")
        if st.button("📋 Prepare JSON Report"):
            report = {
                "rfp_overview":    {k:v for k,v in rfp.items() if k!="raw_text"},
                "compliance":      comp,
                "win_probability": win,
            }
            st.download_button(
                "⬇️ Download JSON",
                data=json.dumps(report, indent=2),
                file_name=f"bid_analysis_{rfp.get('source_file','report')}.json",
                mime="application/json",
            )

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 5 — DRAFT PROPOSAL
    # ══════════════════════════════════════════════════════════════════════════
    with tab5:
        st.markdown("## ✍️ AI Proposal Draft Generator")
        st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)

        questions = rfp.get("key_questions", [])
        if not questions:
            st.warning("No key questions were extracted. Re-upload a more detailed RFP document.")
        else:
            st.markdown(f"""
            <div style="background:linear-gradient(135deg,rgba(255,69,0,0.08),rgba(255,140,0,0.04));
                border:1px solid rgba(255,100,0,0.25); border-radius:8px;
                padding:14px 18px; color:#E8D5C0; font-size:0.9rem; margin-bottom:1rem;">
                🔥 &nbsp;Ready to draft <b style="color:#FFD700;">{len(questions)} proposal sections</b>
                — one per extracted key question, grounded in your Capability Library.
                Each section will be AI-written and fully editable.
            </div>""", unsafe_allow_html=True)

            if st.button("🤖 Generate Full Proposal Draft", type="primary"):
                from utils.proposal_generator import generate_section
                all_sections = []
                prog = st.progress(0, text="Igniting draft generation...")
                for i, q in enumerate(questions):
                    pct = int(((i) / len(questions)) * 100)
                    prog.progress(pct, text=f"✍️ Drafting section {i+1}/{len(questions)}...")
                    sec = generate_section(q, rfp)
                    all_sections.append(sec)
                prog.progress(100, text="✅ All sections drafted!")
                st.session_state.draft_sections = all_sections

            # ── Show drafted sections ─────────────────────────────────────
            if st.session_state.draft_sections:
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown(f"""
                <div style="background:linear-gradient(90deg,rgba(46,204,113,0.1),transparent);
                    border-left:3px solid #2ECC71; border-radius:0 8px 8px 0;
                    padding:12px 18px; color:#2ECC71; font-weight:600;
                    margin-bottom:1rem; font-family:'Rajdhani',sans-serif; font-size:1.1rem;">
                    ✅ {len(st.session_state.draft_sections)} sections generated — review and edit below
                </div>""", unsafe_allow_html=True)

                for i, sec in enumerate(st.session_state.draft_sections, 1):
                    with st.expander(
                        f"📄 Section {i} — {sec['question'][:70]}{'...' if len(sec['question'])>70 else ''}",
                        expanded=(i == 1)
                    ):
                        # Evidence chips
                        if sec.get("evidence_used"):
                            st.markdown("""
                            <div style="color:#9B8878;font-size:0.72rem;
                                letter-spacing:.08em;text-transform:uppercase;
                                margin-bottom:8px;">Supporting Evidence</div>
                            """, unsafe_allow_html=True)
                            e_cols = st.columns(len(sec["evidence_used"]))
                            for ecol, m in zip(e_cols, sec["evidence_used"]):
                                sc = m["score"]
                                cc = "#2ECC71" if sc>=0.25 else "#FF8C00" if sc>=0.15 else "#FF4500"
                                ecol.markdown(f"""
                                <div class="cap-chip">
                                    <div style="color:{cc};font-family:'Rajdhani',sans-serif;
                                        font-weight:700;font-size:0.9rem;">[{m['cap_id']}]</div>
                                    <div style="color:#FFA500;font-size:0.75rem;
                                        margin:2px 0;">{m['domain']}</div>
                                    <div style="color:#9B8878;font-size:0.7rem;">
                                        match {sc:.2f}</div>
                                </div>""", unsafe_allow_html=True)
                            st.markdown("<br>", unsafe_allow_html=True)

                        # Editable text
                        edited = st.text_area(
                            "Edit this section:",
                            value=sec["drafted_text"],
                            height=230,
                            key=f"edit_{i}"
                        )
                        st.session_state.draft_sections[i-1]["drafted_text"] = edited

                # ── Export ──────────────────────────────────────────────────
                st.markdown('<div class="lava-divider"></div>', unsafe_allow_html=True)
                st.markdown("### 📥 Export Final Proposal")

                col_d1, col_d2 = st.columns(2)
                safe = rfp.get('source_file','proposal').replace('.pdf','').replace('.docx','')

                with col_d1:
                    from utils.docx_exporter import export_proposal_to_docx
                    docx_b = export_proposal_to_docx(
                        rfp,
                        st.session_state.draft_sections,
                        comp
                    )
                    st.download_button(
                        "⬇️ Download Word Document (.docx)",
                        data=docx_b,
                        file_name=f"proposal_{safe}.docx",
                        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        use_container_width=True
                    )

                with col_d2:
                    json_out = {
                        "rfp": {k:v for k,v in rfp.items() if k!="raw_text"},
                        "sections": [
                            {"question": s["question"], "draft": s["drafted_text"]}
                            for s in st.session_state.draft_sections
                        ]
                    }
                    st.download_button(
                        "⬇️ Download JSON Export",
                        data=json.dumps(json_out, indent=2),
                        file_name=f"proposal_{safe}.json",
                        mime="application/json",
                        use_container_width=True
                    )

# ── EMPTY STATE ───────────────────────────────────────────────────────────────
else:
    st.markdown("""
    <div style="text-align:center; padding:80px 20px;">
        <div style="font-size:4rem; margin-bottom:16px;">🌋</div>
        <div style="font-family:'Rajdhani',sans-serif; font-size:1.6rem;
            font-weight:700; color:#5C4A3A; margin-bottom:10px;">
            No RFP Loaded
        </div>
        <div style="color:#3D2E1E; font-size:0.95rem; max-width:380px; margin:0 auto;">
            Upload a PDF or DOCX tender document in the sidebar,
            then click <span style="color:#FF6B1A; font-weight:600;">🔥 Ignite Analysis</span>
            to begin.
        </div>
    </div>
    """, unsafe_allow_html=True)